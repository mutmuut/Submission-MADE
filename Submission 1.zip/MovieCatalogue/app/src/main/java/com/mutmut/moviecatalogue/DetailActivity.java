package com.mutmut.moviecatalogue;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    public static String EXTRA_MOVIE = "extra_movie";
    private Movie movies;
    private ImageView poster;
    private TextView txtName;
    private TextView txtRelease;
    private TextView txtRuntime;
    private TextView txtDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        movies = getIntent().getParcelableExtra(EXTRA_MOVIE);
        poster = findViewById(R.id.img_photo);
        txtName = findViewById(R.id.txt_name);
        txtRelease = findViewById(R.id.txt_release);
        txtRuntime = findViewById(R.id.txt_runtime);
        txtDescription = findViewById(R.id.txt_description);

        poster.setImageResource(movies.getPhoto());
        txtName.setText(movies.getName());
        txtRelease.setText(movies.getReleaseDate());
        txtRuntime.setText(movies.getRuntime());
        txtDescription.setText(movies.getDescription());
    }
}
