package com.mutmut.moviecatalogue.TVShows;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.mutmut.moviecatalogue.R;

public class TvDetailActivity extends AppCompatActivity {
    public static String EXTRA_MOVIE = "extra_movie";
    private Tv tvs;
    private ImageView tvPoster;
    private TextView tvName;
    private TextView tvRelease;
    private TextView tvRuntime;
    private TextView tvDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvs = getIntent().getParcelableExtra(EXTRA_MOVIE);
        tvPoster = findViewById(R.id.detail_img);
        tvName = findViewById(R.id.detail_name);
        tvRelease = findViewById(R.id.txt_release);
        tvRuntime = findViewById(R.id.txt_runtime);
        tvDesc = findViewById(R.id.txt_description);

        tvPoster.setImageResource(Integer.valueOf(tvs.getTvPhoto()));
        tvName.setText(tvs.getTvName());
        tvRelease.setText(tvs.getTvReleaseDate());
        tvRuntime.setText(tvs.getTvRuntime());
        tvDesc.setText(tvs.getTvDesc());
    }
}
