package com.mutmut.moviecatalogue.Movies;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.mutmut.moviecatalogue.R;

public class MovieDetailActivity extends AppCompatActivity {
    public static String EXTRA_MOVIE = "extra_movie";
    private Movie movies;
    private ImageView poster;
    private TextView movieName;
    private TextView movieRelease;
    private TextView movieRuntime;
    private TextView movieDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        movies = getIntent().getParcelableExtra(EXTRA_MOVIE);
        poster = findViewById(R.id.detail_img);
        movieName = findViewById(R.id.detail_name);
        movieRelease = findViewById(R.id.txt_release);
        movieRuntime = findViewById(R.id.txt_runtime);
        movieDesc = findViewById(R.id.txt_description);

        poster.setImageResource(Integer.valueOf(movies.getPhoto()));
        movieName.setText(movies.getName());
        movieRelease.setText(movies.getReleaseDate());
        movieRuntime.setText(movies.getRuntime());
        movieDesc.setText(movies.getDescription());
    }
}
