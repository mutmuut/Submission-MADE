package com.mutmut.moviecatalogue.TVShows;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.mutmut.moviecatalogue.R;

import java.util.ArrayList;

public class ListTvAdapter extends RecyclerView.Adapter<ListTvAdapter.CategoryViewHolder> {
    private Context context;
    private ArrayList<Tv> listTv;

    public ListTvAdapter(Context context, ArrayList<Tv> listTv) {
        this.context = context;
        this.listTv = listTv;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<Tv> getListTv() {
        return listTv;
    }

    public void setListTv(ArrayList<Tv> listTv) {
        this.listTv = listTv;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemTv = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tv, viewGroup,false);
        return new CategoryViewHolder(itemTv);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder viewHolder, final int i) {
        viewHolder.txtName.setText(getListTv().get(i).getTvName());
        viewHolder.txtDesc.setText(getListTv().get(i).getTvDesc());
        Glide.with(context)
                .load(Integer.valueOf(getListTv().get(i).getTvPhoto()))
                .apply(new RequestOptions().override(55,75))
                .into(viewHolder.photo);
        viewHolder.itemView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(context, TvDetailActivity.class);
                intent.putExtra(TvDetailActivity.EXTRA_MOVIE, getListTv().get(i));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return getListTv().size();
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView txtName;
        TextView txtDesc;
        ImageView photo;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.item_name_tv);
            txtDesc = itemView.findViewById(R.id.item_description_tv);
            photo = itemView.findViewById(R.id.item_photo_tv);
        }
    }
}
