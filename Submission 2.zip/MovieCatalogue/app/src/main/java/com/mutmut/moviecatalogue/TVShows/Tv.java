package com.mutmut.moviecatalogue.TVShows;

import android.os.Parcel;
import android.os.Parcelable;

public class Tv implements Parcelable {
    private String tvName;
    private String tvDesc;
    private String tvPhoto;
    private String tvReleaseDate;
    private String tvRuntime;

    public Tv(String tvName, String tvDesc, String tvPhoto, String tvReleaseDate, String tvRuntime) {
        this.tvName = tvName;
        this.tvDesc = tvDesc;
        this.tvPhoto = tvPhoto;
        this.tvReleaseDate = tvReleaseDate;
        this.tvRuntime = tvRuntime;
    }

    public Tv() {

    }

    public String getTvName() {
        return tvName;
    }

    public void setTvName(String tvName) {
        this.tvName = tvName;
    }

    public String getTvDesc() {
        return tvDesc;
    }

    public void setTvDesc(String tvDesc) {
        this.tvDesc = tvDesc;
    }

    public String getTvPhoto() {
        return tvPhoto;
    }

    public void setTvPhoto(String tvPhoto) {
        this.tvPhoto = tvPhoto;
    }

    public String getTvReleaseDate() {
        return tvReleaseDate;
    }

    public void setTvReleaseDate(String tvReleaseDate) {
        this.tvReleaseDate = tvReleaseDate;
    }

    public String getTvRuntime() {
        return tvRuntime;
    }

    public void setTvRuntime(String tvRuntime) {
        this.tvRuntime = tvRuntime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.tvName);
        dest.writeString(this.tvDesc);
        dest.writeString(this.tvPhoto);
        dest.writeString(this.tvReleaseDate);
        dest.writeString(this.tvRuntime);
    }

    protected Tv(Parcel in) {
        this.tvName = in.readString();
        this.tvDesc = in.readString();
        this.tvPhoto = in.readString();
        this.tvReleaseDate = in.readString();
        this.tvRuntime = in.readString();
    }

    public static final Parcelable.Creator<Tv> CREATOR = new Parcelable.Creator<Tv>() {
        @Override
        public Tv createFromParcel(Parcel source) {
            return new Tv(source);
        }

        @Override
        public Tv[] newArray(int size) {
            return new Tv[size];
        }
    };
}
