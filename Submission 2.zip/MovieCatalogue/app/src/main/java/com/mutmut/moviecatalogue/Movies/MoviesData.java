package com.mutmut.moviecatalogue.Movies;

import com.mutmut.moviecatalogue.R;

import java.util.ArrayList;

public class MoviesData {
    public static String[][] data = new String[][]{
            {"A Star Is Born", "Seasoned musician Jackson Maine discovers — and falls in love with — struggling artist Ally. She has just about given up on her dream to make it big as a singer — until Jack coaxes her into the spotlight. But even as Ally's career takes off, the personal side of their relationship is breaking down, as Jack fights an ongoing battle with his own internal demons.", String.valueOf(R.drawable.movie_a_start_is_born), "October 3, 2018", "2 hours 15 minutes"},
            {"Alita: Battle Angel", "When Alita awakens with no memory of who she is in a future world she does not recognize, she is taken in by Ido, a compassionate doctor who realizes that somewhere in this abandoned cyborg shell is the heart and soul of a young woman with an extraordinary past.", String.valueOf(R.drawable.movie_alita), "January 31, 2019", "2 hours 2 minutes"},
            {"Aquaman", "Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne.", String.valueOf(R.drawable.movie_aquaman), "December 7, 2018", "2 hours 24 minutes"},
            {"Bohemian Rhapsody", "Singer Freddie Mercury, guitarist Brian May, drummer Roger Taylor and bass guitarist John Deacon take the music world by storm when they form the rock 'n' roll band Queen in 1970. Hit songs become instant classics. When Mercury's increasingly wild lifestyle starts to spiral out of control, Queen soon faces its greatest challenge yet – finding a way to keep the band together amid the success and excess.", String.valueOf(R.drawable.movie_bohemian), "October 24, 2018", "2 hours 15 minutes"},
            {"Cold Pursuit", "Nels Coxman's quiet life comes crashing down when his beloved son dies under mysterious circumstances. His search for the truth soon becomes a quest for revenge as he seeks coldblooded justice against a drug lord and his inner circle.", String.valueOf(R.drawable.movie_cold_persuit), "February 7, 2019", "1 hour 58 minutes"},
            {"Creed II", "Between personal obligations and training for his next big fight against an opponent with ties to his family's past, Adonis Creed is up against the challenge of his life.", String.valueOf(R.drawable.movie_creed), "November 21, 2018", "2 hours 10 minutes"},
            {"Fantastic Beasts: The Crimes of Grindelwald", "Gellert Grindelwald has escaped imprisonment and has begun gathering followers to his cause—elevating wizards above all non-magical beings. The only one capable of putting a stop to him is the wizard he once called his closest friend, Albus Dumbledore. However, Dumbledore will need to seek help from the wizard who had thwarted Grindelwald once before, his former student Newt Scamander, who agrees to help, unaware of the dangers that lie ahead. Lines are drawn as love and loyalty are tested, even among the truest friends and family, in an increasingly divided wizarding world.", String.valueOf(R.drawable.movie_crimes), "November 14, 2018", "2 hours 14 minutes"},
            {"Glass", "In a series of escalating encounters, security guard David Dunn uses his supernatural abilities to track Kevin Wendell Crumb, a disturbed man who has twenty-four personalities. Meanwhile, the shadowy presence of Elijah Price emerges as an orchestrator who holds secrets critical to both men.", String.valueOf(R.drawable.movie_glass), "January 16, 2019", "2 hours 9 minutes"},
            {"How to Train Your Dragon: The Hidden World", "As Hiccup fulfills his dream of creating a peaceful dragon utopia, Toothless’ discovery of an untamed, elusive mate draws the Night Fury away. When danger mounts at home and Hiccup’s reign as village chief is tested, both dragon and rider must make impossible decisions to save their kind.", String.valueOf(R.drawable.movie_how_to_train), "January 3, 2019", "1 hour 44 minutes", "April 25, 2018", "2 hours 29 minutes"},
            {"Mary Queen of Scots", "In 1561, Mary Stuart, widow of the King of France, returns to Scotland, reclaims her rightful throne and menaces the future of Queen Elizabeth I as ruler of England, because she has a legitimate claim to the English throne. Betrayals, rebellions, conspiracies and their own life choices imperil both Queens. They experience the bitter cost of power, until their tragic fate is finally fulfilled.", String.valueOf(R.drawable.movie_marry_queen), "December 7, 2018", "2 hours 4 minutes"},
            {"Master Z: Ip Man Legacy", "After being defeated by Ip Man, Cheung Tin Chi is attempting to keep a low profile. While going about his business, he gets into a fight with a foreigner by the name of Davidson, who is a big boss behind the bar district. Tin Chi fights hard with Wing Chun and earns respect.", String.valueOf(R.drawable.movie_master_z), "December 20, 2018", "1 hour 47 minutes"},
            {"Mortal Engines", "Many thousands of years in the future, Earth’s cities roam the globe on huge wheels, devouring each other in a struggle for ever diminishing resources. On one of these massive traction cities, the old London, Tom Natsworthy has an unexpected encounter with a mysterious young woman from the wastelands who will change the course of his life forever.", String.valueOf(R.drawable.movie_mortal_engines), "November 27, 2018", "2 hours 9 minutes"},
            {"Overlord", "France, June 1944. On the eve of D-Day, some American paratroopers fall behind enemy lines after their aircraft crashes while on a mission to destroy a radio tower in a small village near the beaches of Normandy. After reaching their target, the surviving paratroopers realise that, in addition to fighting the Nazi troops that patrol the village, they also must fight against something else.", String.valueOf(R.drawable.movie_overlord), "November 1, 2018", "1 hour 50 minutes"},
            {"Ralph Breaks the Internet", "Video game bad guy Ralph and fellow misfit Vanellope von Schweetz must risk it all by traveling to the World Wide Web in search of a replacement part to save Vanellope's video game, \"Sugar Rush.\" In way over their heads, Ralph and Vanellope rely on the citizens of the internet -- the netizens -- to help navigate their way, including an entrepreneur named Yesss, who is the head algorithm and the heart and soul of trend-making site BuzzzTube.", String.valueOf(R.drawable.movie_poster_ralph), "November 20, 2018", "1 hour 52 minutes"},
            {"Robin Hood", "A war-hardened Crusader and his Moorish commander mount an audacious revolt against the corrupt English crown.", String.valueOf(R.drawable.movie_robin_hood), "November 20, 2018", "1 hour 56 minutes"},
            {"Serenity", "Baker Dill is a fishing boat captain leading tours off a tranquil, tropical enclave called Plymouth Island. His quiet life is shattered, however, when his ex-wife Karen tracks him down with a desperate plea for help.", String.valueOf(R.drawable.movie_serenity), "January 24, 2019", "1 hour 46 minutes"},
            {"Spider-Man: Into the Spider-Verse", "Miles Morales is juggling his life between being a high school student and being a spider-man. When Wilson \"Kingpin\" Fisk uses a super collider, others from across the Spider-Verse are transported to this dimension.", String.valueOf(R.drawable.movie_spiderman), "December 7, 2018", "1 hour 57 minutes"},
            {"T-34", "In 1944, a courageous group of Russian soldiers managed to escape from German captivity in a half-destroyed legendary T-34 tank. Those were the times of unforgettable bravery, fierce fighting, unbreakable love, and legendary miracles.", String.valueOf(R.drawable.movie_t34), "December 28, 2018", "2 hours 19 minutes"},
    };

    public static ArrayList<Movie> getListData(){
        ArrayList<Movie> list = new ArrayList<>();
        for (String[] aData : data){
            Movie movie = new Movie();
            movie.setName(aData[0]);
            movie.setDescription(aData[1]);
            movie.setPhoto(aData[2]);
            movie.setReleaseDate(aData[3]);
            movie.setRuntime(aData[4]);

            list.add(movie);
        }
        return list;
    }
}
